### v0.5.3
<ul>
    <li>hotfix for items sometimes not sending until the next run</li>
    <li>hotfix for progressive stamina bars not loading properly</li>
    <li>Sudden disconnects will attempt reconnection</li>
    <li>AP UI will reset if reconnect attempts fail showing the Connection UI</li>
</ul>

### v0.5.2
<ul>
    <li>Hotfix for Traps not working if TrapLink was disabled</li>
    <li>Hotfix for assetbundle loading when downloaded through a mod manager</li>
    <li>Luggage Checks Per Run now properly resets</li>
    <li>EnergyLink wasn't properly communicating with the server</li>
    <li>Item mapping changed to IDs for more consistent results</li>
    <li>Yeet Trap needed updating due to one of the later post ROOTS updates</li>
</ul>

### v0.5.1
<ul>
    <li>hotfix for Death Links breaking when players are still waking up on the SHORE</li>
    <li>hotfix for save state loading logic happening out of order</li>
</ul>

### v0.5.0
<ul>
    <li>A handful of new Traps</li>
    <li>Energy Link support</li>
    <li>Save state handling reworked</li>
    <li>Item Check fixes</li>
    <li>Badge Check fixes</li>
    <li>Ascent Unlocks changed to Progressive Ascent</li>
    <li>Ascent Completion checks wont populate higher than your Ascent Level for the Peak Reached Goal</li>
</ul>

### v0.4.9
<ul>
    <li>Updated for Archipelago 0.6.4's new manifest</li>
</ul>

### v0.4.8
<ul>
    <li>Fixed save state loading was happening too early resulting in mixed up Luggage Checks</li>
    <li>DeathLink Checkpoint behavior should now be working properly</li>
    <li>Fixed ROOTS Ascent badge checks weren't sending properly</li>
    <li>HardRingLink support for certain conditions</li>
</ul>

### v0.4.7
<ul>
    <li>Luggage checks working in multiplayer (Without the mod too)</li>
    <li>AP Messages can be seen by others with the mod</li>
    <li>Progressive stamina working with others with the mod</li>
    <li>Fixed affliction traps not working on other players</li>
    <li>Fixed Death Links not sending due to the ROOTS update</li>
    <li>Added Badge checks for the ROOTS update badges</li>
    <li>Added Acquire Item checks for ROOTS update items</li>
    <li>Removed the unused Acquire Campfire check</li>
    <li>Added some new traps related to the ROOTS update</li>
    <li>Added missing item check(s): Marshmallow</li>
    <li>AP UI will change when joining a server to be less obtrusive</li>
</ul>