### v0.4.7
Luggage checks working in multiplayer (Without the mod too)
AP Messages can be seen by others with the mod
Progressive stamina working with others with the mod
Fixed affliction traps not working on other players
Fixed Death Links not sending due to the ROOTS update
Added Badge checks for the ROOTS update badges
Added Acquire Item checks for ROOTS update items
Removed the unused Acquire Campfire check
Added some new traps related to the ROOTS update
Added missing item check(s): Marshmallow
AP UI will change when joining a server to be less obtrusive